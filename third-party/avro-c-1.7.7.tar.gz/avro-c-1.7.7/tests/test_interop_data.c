#include "avro_private.h"
#include <stdio.h>

int main(void)
{
	return 0;
}
